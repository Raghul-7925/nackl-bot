require('dotenv').config();
console.log('NACKL Bot template');
